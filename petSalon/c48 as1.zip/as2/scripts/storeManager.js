function saveItem(key, item) {
    let val = JSON.stringify(item); // Convert the object to a JSON string
    localStorage.setItem(key, val); // Store the JSON string in local storage
}

function getItem(key) {
    let val = localStorage.getItem(key); // Get the JSON string from local storage
    if (val) {
        return JSON.parse(val); // Parse the JSON string
    }
    return null;
}

function deleteItem(key) {
    localStorage.removeItem(key); // Remove the item from local storage
}

function readItems(){
    let data = localStorage.getItem("services");//getting the values from the LS

    if(!data){//NOT data?
        return [];// creating the array
    }else{
        let list = JSON.parse(data);//parse back into an array
        return list; // Return the parsed array
    }
}